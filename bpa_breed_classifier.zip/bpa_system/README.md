# Bharat Pashudhan App — AI Breed Identification System

AI-powered cattle and buffalo breed classification tool for Field Level Workers (FLWs),
built for integration with the Bharat Pashudhan App (BPA).

---

## Project Structure

```
bpa_system/
├── app.py               ← Python Flask backend (AI inference API)
├── requirements.txt     ← Python dependencies
├── static/
│   └── index.html       ← Frontend website (served by Flask)
├── model_cache/         ← Auto-created; stores downloaded ONNX model
└── uploads/             ← Auto-created; temporary image uploads
```

---

## Quickstart

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the server

```bash
python app.py
```

The server downloads the model from HuggingFace automatically on first run (~90 MB).
Open http://localhost:5000 in your browser.

---

## API Endpoints

| Method | Endpoint            | Description                          |
|--------|---------------------|--------------------------------------|
| GET    | /                   | Frontend website                     |
| GET    | /api/health         | Health check + model status          |
| GET    | /api/breeds         | Full breed metadata (JSON)           |
| POST   | /api/predict        | Classify image → breed + confidence  |
| GET    | /api/predict/demo   | Random demo prediction (no image)    |

### POST /api/predict

**Option A — File upload (multipart/form-data):**
```bash
curl -X POST http://localhost:5000/api/predict \
  -F "image=@/path/to/cow.jpg"
```

**Option B — Base64 JSON:**
```bash
curl -X POST http://localhost:5000/api/predict \
  -H "Content-Type: application/json" \
  -d '{"image_base64": "<base64-encoded-image>"}'
```

**Response:**
```json
{
  "breed": "Gir",
  "confidence": 0.9341,
  "animal_type": "Cattle",
  "top_5": [
    {"breed": "Gir",      "score": 0.9341},
    {"breed": "Sahiwal",  "score": 0.0412},
    {"breed": "Kankrej",  "score": 0.0247}
  ],
  "inference_ms": 47.2,
  "metadata": {
    "type": "Cattle",
    "origin": "Gujarat",
    "purpose": "Dairy",
    "milk_yield": "6-12 L/day",
    "fat_pct": "4.5%"
  },
  "demo_mode": false
}
```

---

## CLI Usage

You can also run breed identification directly from the command line:

```bash
python app.py path/to/animal_image.jpg
```

---

## Supported Breeds

### Cattle (5)
| Breed       | Origin            | Purpose      |
|-------------|-------------------|--------------|
| Gir         | Gujarat           | Dairy        |
| Sahiwal     | Punjab/Rajasthan  | Dairy        |
| Ongole      | Andhra Pradesh    | Dual purpose |
| Kankrej     | Gujarat/Rajasthan | Dual purpose |
| Tharparkar  | Rajasthan         | Dual purpose |

### Buffalo (5)
| Breed       | Origin         | Purpose | Fat %    |
|-------------|----------------|---------|----------|
| Murrah      | Haryana/Punjab | Dairy   | 7–8%     |
| Surti       | Gujarat        | Dairy   | 8–9%     |
| Jaffarbadi  | Gujarat        | Dairy   | 7–8%     |
| Mehsana     | Gujarat        | Dairy   | 7–8%     |
| Bhadawari   | UP/MP          | Dairy   | 10–13%   |

---

## AI Model

- **Repository:** vishnuamar/cattle-breed-classifier (HuggingFace)
- **Architecture:** ResNet-50 backbone + L2 normalisation
- **Format:** ONNX (89.6 MB)
- **Classification:** Cosine similarity with breed prototype vectors
- **Inference time:** ~45–50ms on CPU

---

## Demo Mode

If `onnxruntime` or `huggingface_hub` are not installed, the server runs in
**demo mode** — returning plausible random predictions so the frontend still works.
The frontend will show a warning banner when demo mode is active.

---

## License

Apache 2.0 — see model repository for full details.
